<!doctype html>
<html lang="en">

<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <link rel="icon" href="/favicon.ico" type="image/svg+xml" />
  <link rel="apple-touch-icon" href="/favicon.ico" type="image/svg+xml" />

  <title>PEAP Token Crypto Presale | PEPE Ascension Token</title>
  <meta name="title" charset="utf-8" content="PEAP Token Crypto Presale | PEPE Ascension Token" />
  <meta name="description"
    content="PEPE Ascension Presale | Unlock wealth, strength, and a meme revolution. Dive into the golden age of crypto with the $PEAP token!" />
  <meta name="robots" content="index,follow" />
  <!-- <link rel="canonical" href="https://pepeascension.com/" /> -->
  <meta name="keywords"
    content="ascension, Pepe ascension, PEPE, BLOCKCHAIN,PEAP, $PEAP Token, Token, Presale, Staking, Claim $PEAP, Pepe Ascension Presale is lived!" />
  <!-- Facebook Meta Tags -->
  <meta property="og:url" content="https://pepeascension.com/" />
  <meta property="og:type" content="website" />
  <meta property="og:title" content="PEAP Token Crypto Presale | PEPE Ascension Token" />
  <meta property="og:description"
    content="PEPE Ascension Presale | Unlock wealth, strength, and a meme revolution. Dive into the golden age of crypto with the $PEAP token!" />
  <meta name="og:image" content="https://pepeascension.com/assets/images/social-frame-2.png" />

  <!-- Twitter Meta Tags -->
  <meta name="twitter:card" content="summary_large_image" />
  <meta property="twitter:domain" content="https://pepeascension.com/" />
  <meta property="twitter:url" content="https://pepeascension.com/" />
  <meta name="twitter:title" content="PEAP Token Crypto Presale | PEPE Ascension Token" />
  <meta name="twitter:description"
    content="PEPE Ascension Presale | Unlock wealth, strength, and a meme revolution. Dive into the golden age of crypto with the $PEAP token!" />
  <meta name="twitter:image" content="https://pepeascension.com/assets/images/social-frame-2.png" />

  <!-- <link rel="preconnect" href="https://fonts.googleapis.com" /> -->
  <!-- <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin /> -->
  <!-- <link
    href="https://fonts.googleapis.com/css2?family=DM+Sans:ital,opsz,wght@0,9..40,100..1000;1,9..40,100..1000&display=swap"
    rel="stylesheet" /> -->
  <script type="module" crossorigin src="/assets/index-Dm5-ab8B.js"></script>
  <link rel="stylesheet" crossorigin href="/assets/index-Duqvvwqw.css">
</head>

<body>
  <noscript>You need to enable JavaScript to run this app.</noscript>
  <div id="root"></div>

  <!-- Google tag (gtag.js) -->
  <script async src="https://www.googletagmanager.com/gtag/js?id=G-4VD8V5YNV5"></script>
  <script>
    window.dataLayer = window.dataLayer || []
    function gtag() {
      dataLayer.push(arguments)
    }
    gtag('js', new Date())

    gtag('config', 'G-4VD8V5YNV5')
  </script>

  <!-- Meta Pixel Code -->
  <script>
    !(function (f, b, e, v, n, t, s) {
      if (f.fbq) return
      n = f.fbq = function () {
        n.callMethod
          ? n.callMethod.apply(n, arguments)
          : n.queue.push(arguments)
      }
      if (!f._fbq) f._fbq = n
      n.push = n
      n.loaded = !0
      n.version = '2.0'
      n.queue = []
      t = b.createElement(e)
      t.async = !0
      t.src = v
      s = b.getElementsByTagName(e)[0]
      s.parentNode.insertBefore(t, s)
    })(
      window,
      document,
      'script',
      'https://connect.facebook.net/en_US/fbevents.js'
    )
    //fbq('init', '1116658813146711')
    fbq('init', '1686551315289381')
    fbq('track', 'PageView')
    // fbq('track', 'AddToCart')
    // fbq('track', 'Purchase')
  </script>
  <noscript><img height="1" width="1" style="display: none"
      src="https://www.facebook.com/tr?id=1116658813146711&ev=PageView&noscript=1" /></noscript>
  <!-- End Meta Pixel Code -->

  <script type="text/javascript">
    adroll_adv_id = '4NJN6I7CJ5DODAYVQHOTNF'
    adroll_pix_id = '3VNZRTAYRZAHVG32BUJOHR'
    adroll_version = '2.0'
      ; (function (w, d, e, o, a) {
        w.__adroll_loaded = true
        w.adroll = w.adroll || []
        w.adroll.f = ['setProperties', 'identify', 'track', 'identify_email']
        var roundtripUrl =
          'https://s.adroll.com/j/' + adroll_adv_id + '/roundtrip.js'
        for (a = 0; a < w.adroll.f.length; a++) {
          w.adroll[w.adroll.f[a]] =
            w.adroll[w.adroll.f[a]] ||
            (function (n) {
              return function () {
                w.adroll.push([n, arguments])
              }
            })(w.adroll.f[a])
        }
        e = d.createElement('script')
        o = d.getElementsByTagName('script')[0]
        e.async = 1
        e.src = roundtripUrl
        o.parentNode.insertBefore(e, o)
      })(window, document)
    adroll.track('pageView')
    // adroll.track('addToCart')
    // adroll.track('purchase')
  </script>
  <script defer data-domain="pepeascension.com"
    src="https://plausible.io/js/script.file-downloads.hash.outbound-links.pageview-props.revenue.tagged-events.js"></script>

  <!-- Criteo Loader File -->
  <script type="text/javascript" src="//dynamic.criteo.com/js/ld/ld.js?a=117980" async="true"></script>
  <!-- END Criteo Loader File -->
</body>

</html>